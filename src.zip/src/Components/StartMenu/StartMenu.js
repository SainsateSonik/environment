import React from "react";
import { connect } from "react-redux";

import "./StartMenu.css";
import {appList, quickAccess} from "../../data/startMenu/list_items";

const startMenu = (props) => {
    return(
        <section id="start-menu"
                 className={props.showMenu ? "showMenu" : "hideMenu"}>
            <ul className={props.showMenu ? "showApps" : "hideApps"}>
                {appList.map((appData, index) => (
                    <li key={index}
                        className="appItem">
                            <img src={appData.app} alt={appData.desc}/>
                            <span>{appData.appName}</span>
                    </li>
                ))}
            </ul>
            <ul>
                {quickAccess.map((item, index) => (
                    <li key={index} 
                        className="quickAccessItem">
                            {item}
                    </li>
                ))}
            </ul>
        </section>
    );
};

const mapStateToProps = (state) => {
    return { showMenu: state.showMenu };
};

export default connect(mapStateToProps)(startMenu);