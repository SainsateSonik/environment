import React from "react";
import { connect } from 'react-redux';
import "./NavigationToolbar.css";

import windowsStart from '../../resources/icons/navigationToolbar/windowsStart.png';
import windowsExplorer from '../../resources/icons/navigationToolbar/windowsExplorer.png';
import googleChrome from '../../resources/icons/navigationToolbar/googleChrome.png';

import actionTypes from '../../store/ActionTypes';

const navigationToolbar = (props) => {
    return(
        <nav>
          <ul>
            <li><img src={windowsStart} alt="Start Icon" onClick={props.toggleMenu}/></li>
            <li><img src={windowsExplorer} alt="Explorer Icon"/></li>
            <li><img src={googleChrome} alt="Chrome Icon"/></li>
          </ul>
        </nav>
    );
};

const mapDispatchToProps = (dispatch) => {
    return {
        toggleMenu : () => dispatch({type: actionTypes.navigation.TOGGLE_MENU})
    };
};

export default connect(null, mapDispatchToProps)(navigationToolbar);