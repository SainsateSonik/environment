export default {
    navigation: {
        TOGGLE_MENU: "TOGGLE_MENU"
    }
};