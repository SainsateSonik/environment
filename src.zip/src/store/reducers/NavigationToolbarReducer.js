import actionTypes from '../ActionTypes';

const intitialState = {
    showMenu : false
};

const reducer = (state=intitialState, action) => {
    switch(action.type) {
        case actionTypes.navigation.TOGGLE_MENU:
            return { showMenu : !state.showMenu };
        default:
            return state;
    }
};

export default reducer;

