import atom from '../../resources/icons/startMenu/atom.png';
import calculator from '../../resources/icons/startMenu/calculator.png';
import notepad from '../../resources/icons/startMenu/notepad.png';
import notes from '../../resources/icons/startMenu/notes.png';
import outlook from '../../resources/icons/startMenu/outlook.png';
import terminal from '../../resources/icons/startMenu/terminal.png';
import vscode from '../../resources/icons/startMenu/vscode.png';

export const appList = [
    {app: outlook, appName: "Outlook", desc: "outlook logo"},
    {app: atom, appName: "Atom", desc: "atom logo"},
    {app: vscode, appName: "Visual Studio Code", desc: "vscode logo"},
    {app: notepad, appName: "Notepad", desc: "notepad logo"},
    {app: notes, appName: "Sticky Notes", desc: "notes logo"},
    {app: calculator, appName: "Calculator", desc: "calculator logo"},
    {app: terminal, appName: "Terminal", desc: "terminal logo"}
];

export const quickAccess = [
    "Documents", "Pictures", "Music", "Computer", "Help & Support"
];
 