import React, { Component } from 'react';
import './App.css';

import NavigationToolbar from './Components/NavigationToolbar/NavigationToolbar';
import StartMenu from './Components/StartMenu/StartMenu';

class App extends Component {
  render() {
    return (
      <div id="window-screen">
        <NavigationToolbar />
        <StartMenu />
      </div>
    );
  }
}

export default App;
